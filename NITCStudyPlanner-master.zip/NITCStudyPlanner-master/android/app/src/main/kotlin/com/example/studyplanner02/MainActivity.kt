package com.example.studyplanner02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
